<!--Lirerias-->
<script src="<?php echo $path; ?>assets/js/jquery-3.6.0.min.js"></script>
<script src="<?php echo $path; ?>assets/vendors/bootstrap-5.0.2/js/popper.min.js"></script>
<script src="<?php echo $path; ?>assets/vendors/bootstrap-5.0.2/js/bootstrap.min.js"></script>
<script src="<?php echo $path; ?>assets/vendors/fontawesome-5.15.4/js/fontawesome.min.js"></script>
<script src="<?php echo $path; ?>assets/vendors/fontawesome-5.15.4/js/all.min.js"></script>
<script src="<?php echo $path; ?>assets/vendors/sweetalert2/sweetalert2.all.min.js"></script>
<script src="<?php echo $path; ?>assets/vendors/swiper/swiper-bundle.min.js"></script>
<script src="<?php echo $path; ?>assets/vendors/apexcharts/apexcharts.min.js"></script>

<script src="<?php echo $path; ?>service/async.js"></script>
<script src="<?php echo $path; ?>service/general/alertas.js"></script>

<script src="<?php echo $path; ?>service/cart.js"></script>