<meta charset="UTF-8">
<meta name="viewport"
      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<!-- Librerias CSS -->
<link rel="stylesheet" href="<?php echo $path; ?>assets/vendors/bootstrap-5.0.2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $path; ?>assets/vendors/bootstrap-5.0.2/css/">
<link rel="stylesheet" href="<?php echo $path; ?>assets/vendors/apexcharts/apexcharts.css">
<link rel="stylesheet" href="<?php echo $path; ?>assets/vendors/fontawesome-5.15.4/css/fontawesome.min.css">
<link rel="stylesheet" href="<?php echo $path; ?>assets/vendors/swiper/swiper-bundle.min.css">
<link rel="stylesheet" href="<?php echo $path; ?>assets/vendors/sweetalert2/sweetalert2.min.css">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
<link rel="stylesheet" href="<?php echo $path; ?>assets/css/style.css">
<title><?php echo $titulo; ?></title>