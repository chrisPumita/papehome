<?php
    session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <?php include "./includes_general/header.php" ?>
    <title>Bievenido a la tienda</title>
</head>
<body>
<?php include "./includes_general/nav.php" ?>
<section>
    <h1>HOLA</h1>
</section>
<?php include "./includes_general/footer.php" ?>
<?php include "./includes_general/js.php" ?>
</body>
</html>