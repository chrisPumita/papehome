$( document ).ready(function() {
    loadPromos();
});