<script src="./assets/js/jquery-3.6.0.min.js"></script>
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/popper.js"></script>
<script src="./assets/bootstrap-5.0.2/js/bootstrap.min.js"></script>
<script src="./assets/js/main.js"></script>
