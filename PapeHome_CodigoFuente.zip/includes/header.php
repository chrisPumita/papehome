<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="./assets/bootstrap-5.0.2/css/bootstrap.min.css">
<!-- Font Awesome Icons -->
<script src="./assets/fontawesome/42d5adcbca.js" crossorigin="anonymous"></script>
<!-- Link Swiper's CSS -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
<link rel="stylesheet" href="./assets/swiper/swiper-bundle.min.css"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="./assets/css/style.css"/>